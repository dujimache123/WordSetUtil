--- 定幅奖励widget 组件
local RoundAwardWidgetCom = class("RoundAwardWidgetCom", require("bomblord.util.Component"))
local ResourceManager = require("bomblord.util.ResourceManager")
local PrefabDef = require("bomblord.def.PrefabDef")
local RequireDef = require("bomblord.def.RequireDef")
local UserInfo = RequireDef.UserInfo

function RoundAwardWidgetCom:awake()
    RoundAwardWidgetCom.super.awake(self)
	local go = self.gameObject_
	go.lab_up_:setVisible(false)
end

---更新定幅奖励
---@param matchData table
function RoundAwardWidgetCom:updateViewData(matchData)
    if matchData then
        local tGcData = matchData:getGameCountAwardData()
        local adItem = tGcData and tGcData:getNextCountAwardInfo()
	    if adItem and (adItem:getCount() >= adItem:getFinishCount()) then
		    local finishCnt = adItem:getFinishCount()
		    local targetCnt = adItem:getCount()
		    local txt = string.format("%d/%d     %d%s", finishCnt % targetCnt, targetCnt,
				    adItem:getAmount(), adItem:getName())
		    self.gameObject_.lab_award_:setText(txt)
		    self.gameObject_.progress_:setValue((finishCnt % targetCnt) * 100 / targetCnt)
	    else
		    self.gameObject_:setVisible(false)
	    end
    end
end

function RoundAwardWidgetCom:qiuKaJiangLiAction(count)
	local go = self.gameObject_
	local tActions = CCArray:create()
	tActions:addObject(JJAction:repeatAction(JJAction:sequence(JJAction:rotateTo(0.05, 25), JJAction:rotateTo(0.1,
			-25)), 3))
	tActions:addObject(JJAction:callFunc(function ()
		go.icon_:setRotation(0)
	end))
	tActions:addObject(JJAction:delayTime(0.3))
	tActions:addObject(JJAction:repeatAction(JJAction:sequence(JJAction:rotateTo(0.05, 25), JJAction:rotateTo(0.1,
			-25)), 3))
	tActions:addObject(JJAction:callFunc(function ()
		go.icon_:setRotation(0)
	end))
	tActions:addObject(JJAction:callFunc(function ()
		go.lab_up_:setVisible(true)
		go.lab_up_:setText("+" .. count)
		go.lab_up_:runAction(JJAction:sequence(
			JJAction:moveBy(0.5, ccp(0, 50)),
			JJAction:callFunc(handler(self, self.showAward)),
			JJAction:delayTime(1.5),
			JJAction:fadeOut(1)
		))
	end))
	go.icon_:runAction(CCSequence:create(tActions))
end

function RoundAwardWidgetCom:showAward()
	local go = self.gameObject_
	local figure = ResourceManager:createGameObject(PrefabDef.FIGURE, go)
	go:addView(figure)
    local com = figure:getComponent("FigureWidgetCom")
	com:setData({
		userId = UserInfo.userId_,
		figureId = UserInfo.figureId_,
		size = 70
	})
	figure:setPosition(-200, -200)

	figure:runAction(JJAction:moveBy(0.25, ccp(0, 200)))

	local qiukaIcon = jj.ui.JJImage.new({
		image = self.theme_:getImage("common/bottom_gold_qiuka.png")
	})
	go:addView(qiukaIcon)
	qiukaIcon:setPosition(go.icon_:getPositionInPoint())
	qiukaIcon:runAction(JJAction:sequence(
		JJAction:jumpTo(0.5, ccp(-200, 0), 200, 1),
		JJAction:fadeOut(0.1),
		JJAction:delayTime(0.5),
		JJAction:callFunc(function()
			figure:runAction(JJAction:moveBy(0.2, ccp(0, -200)))
		 end)
	))
end

return RoundAwardWidgetCom