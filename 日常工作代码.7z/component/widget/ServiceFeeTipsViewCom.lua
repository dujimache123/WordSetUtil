-- 玩家名片组件
local ServiceFeeTipsViewCom = class("ServiceFeeTipsViewCom", require("bomblord.util.Component"))
local RequireDef = require("bomblord.def.RequireDef")
local EventIdDefine = RequireDef.EventIdDefine

function ServiceFeeTipsViewCom:awake()
    ServiceFeeTipsViewCom.super.awake(self)
    self:registerEvent()
    self:setTipsVisible(false)
end

function ServiceFeeTipsViewCom:registerEvent()
    self:addEventListener(EventIdDefine.SERVICE_CHARGE_TIPS, self.handleShowTips)
end

function ServiceFeeTipsViewCom:setData(text)
    local go = self.gameObject_
    go.tips_:setOpacity(165)
    go.tips_:setText(text)
end

function ServiceFeeTipsViewCom:setTipsVisible(flag)
    local go = self.gameObject_
    go.tips_:setVisible(flag)
end

function ServiceFeeTipsViewCom:doAction()
    local go = self.gameObject_
    go:stopAllActions()
    self:setTipsVisible(true)
    local actArray = CCArray:create()
    actArray:addObject(JJAction:delayTime(3))
    actArray:addObject(JJAction:callFunc(function()
        self:setTipsVisible(false)
    end))
    go:runAction(JJAction:sequence(actArray))
end

function ServiceFeeTipsViewCom:handleShowTips(msg, lordData)
    if not lordData then return end
    local selfSeat = lordData:getSelfSeat()
    if not selfSeat then return end
    local ack = msg.bomblord_ack_msg.startgame_ack_msg
    local playerScoreList = ack.playerscore
    if not playerScoreList then return end
    local selfPlayerInfo = lordData:getPlayerInfo(selfSeat)
    if not selfPlayerInfo then return end
    local textString = "已收取服务费"
    local selfScore = selfPlayerInfo:getScore()
    local fee = selfPlayerInfo:getServiceFee()
    local isShow = false
    for i, v in ipairs(playerScoreList) do
        local seat = v.seat
        --local score = v.score
        if seat and seat == selfSeat then
            isShow = true
        end
    end

    if isShow and fee > 0 then
        self:setData(textString .. fee)
        self:doAction()
    end
end

return ServiceFeeTipsViewCom