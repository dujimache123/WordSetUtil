-- 玩家名片组件
local PopupUserInfoViewCom = class("PopupUserInfoViewCom", import(".PopupBase"))
local ResourceManager = require("bomblord.util.ResourceManager")
local PrefabDef = require("bomblord.def.PrefabDef")
local ConstDefine = require("bomblord.def.ConstDef")
local UserInfo = jj.game.UserInfo
local VIPConfig = jj.game.VIPConfig
local Well = jj.game.Well
local NoteMsg = jj.game.NoteMsg
local NoteMsgDef = jj.game.NoteMsgDef
local MainController = jj.game.MainController
local JJSceneDef = jj.game.JJSceneDef
local GROW_DEF = ConstDefine.GROW_DEF

function PopupUserInfoViewCom:awake()
    PopupUserInfoViewCom.super.awake(self)
    self:initView()
    self:showWithAnim()
end

function PopupUserInfoViewCom:initView()
    local go = self.gameObject_
    self:enableTouch(go.virutalbtn_, function ()
    end)
    self:initPlayerInfoView()
    go.grp_root_:setOpacity(0)
    go.grp_root_:runAction(JJAction:sequenceWithTwoActions(
            JJAction:delayTime(0.2),
            JJAction:fadeIn(0.5)
    ))

    go.eff_bg_:registerSpineEventHandler(function()
        go.eff_bg_:setAnimation(0, "chixu", true)
    end, sp.EventType.ANIMATION_COMPLETE)
end

function PopupUserInfoViewCom:initPlayerInfoView()
    if self:isDestroyed() then return end
    local go = self.gameObject_
    go.nickname_:setWithEllipsis(true)
    go.nickname_:setViewSize(390, 60)
    go.nickname_:setWidthWrapContent(false)

    go.addcoinbtn_:setClickAreaSize(75, 75)
    go.addqiukabtn_:setClickAreaSize(75, 75)
    go.addcoinbtn_:setOnClickListener(handler(self, self.onClickBuyGold))
    go.addqiukabtn_:setOnClickListener(handler(self, self.onClickBtnQiuKaPlus))
    go.messagebtn_:setOnClickListener(handler(self, self.onClickMail))
    go.settingbtn_:setOnClickListener(handler(self, self.onClickSetting))
    self:createFigureHead()
    self:upDateUserData()
end

function PopupUserInfoViewCom:setNicknameText(text)
    if self:isDestroyed() then return end
    local go = self.gameObject_
    go.nickname_:setText(tostring(text) or "")
end

---createFigureHead
---创建头像
function PopupUserInfoViewCom:createFigureHead()
    if self:isDestroyed() then return end
    local go = self.gameObject_
    local figure = ResourceManager:createGameObject(PrefabDef.FIGURE, go)
    go.head_:addView(figure)
    local com = figure:getComponent("FigureWidgetCom")
    com:setData({
        userId = UserInfo.userId_,
        figureId = UserInfo.figureId_,
        size = 108,
        shape = 2
    })
end

---upDateUserData
---更新玩家数据
function PopupUserInfoViewCom:upDateUserData()
    if self:isDestroyed() then return end
    local go = self.gameObject_
    local gold = UserInfo.gold_
    local nickname = UserInfo.nickname_
    local qiuka = UserInfo:getQiuKaCount()
    local vipTitle = string.gsub(VIPConfig:getTitle(), "用户", "")
    local totalExp = UserInfo.totalScore_
    local exp = UserInfo:getGrowCount(GROW_DEF.EXP)
    local isShowBombLordExp = (exp ~= 0)
    go.expgroup_:setVisible(isShowBombLordExp)

    go.nickname_:setText(nickname)
    go.coin_:setText(gold)
    go.qiuka_:setText(qiuka)
    if vipTitle then
        go.level_:setText(vipTitle)
    end
    go.totalexp_:setText(totalExp)
    go.bomblordexp_:setText(exp)
end

function PopupUserInfoViewCom:onClickBuyGold()
    Well:chargeBtnHandler()
end

function PopupUserInfoViewCom:onClickMail()
    local packageId = MainController:getCurPackageId()
    if MainController:isLogin() then
        local item = NoteMsg:getUnreadTreasureData(packageId, UserInfo.userId_, packageId,
                NoteMsgDef.MODE_PUSHTREASURE)
        local params = {}
        if item then
            params.item = item
            MainController:pushScene(packageId, JJSceneDef.ID_NOTE_MSG_DETAIL, params)
        else
            MainController:pushScene(packageId, JJSceneDef.ID_NOTE_MSG)
        end
        NoteMsg:setIsNewMsg(packageId, false)
    else
        self.viewController_:startLogin()
    end
end

function PopupUserInfoViewCom:onClickSetting()
    MainController:pushScene(MainController:getCurPackageId(), JJSceneDef.ID_SETTINGS)
end

function PopupUserInfoViewCom:onClickBtnQiuKaPlus()
    if MainController:isLogin() then
        jj.game.JJGameUtil:openWebViewCoin()
    else
        self.viewController_:startLogin()
    end
end

return PopupUserInfoViewCom