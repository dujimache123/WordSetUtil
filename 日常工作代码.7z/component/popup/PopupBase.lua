--[[--
	弹窗控制器基类，主要提供全屏mask
]]
local PopupBase = class("PopupBase", require("bomblord.util.Component"))
local PopupManager = require("bomblord.util.PopupManager")
local ComponentDef = require("bomblord.def.ComponentDef")

local UI_TAG = {
	CloseButton = 100,
    Bg = 101,
    Mask = 102,
}

--[[--
	弹窗的构造方法
	@param parent: type table, 父类视图
]]
function PopupBase:awake()
	PopupBase.super.awake(self)
    local topController = SceneStack:getTop()
    self.viewController_ = topController
    self.scene_ = topController.scene_
    self:initMask()
    self:registerBtnCloseListener()
end

function PopupBase:onDestroy()
    PopupBase.super.onDestroy(self)
    if self.mask_ and not self.mask_:isDestoryed() then
        self.mask_:removeSelf(true)
        self.mask_ = nil
    end
end

function PopupBase:variateDef()
    self.name_ = nil
    self.viewController_ = nil
    self.managerCallback_ = nil --弹出管理类关闭时回调
    self.customCloseCallback_ = nil  --自定义关闭时回调
    self.mask_ = nil --蒙黑层透明度设置
end

function PopupBase:setName(name)
    self.name_ = name
end

function PopupBase:getName()
    return self.name_
end

--[[--
	初始化弹窗信息，如尺寸、标题等
]]
function PopupBase:initMask()
	--背景遮罩
	self.mask_ = jj.ui.JJViewGroup.new({viewSize = CCSize(1, 1)})
    self.mask_:setId(UI_TAG.Mask)
    self.mask_:setBackground({color4 = ccc4(0,0,0,80)})
    self.mask_:setAnchorPoint(0, 0)
    self.scene_:addView(self.mask_)

    local size = ScreenSizeManager:getSize()
    -- 容错处理
    if not size then
        local director = CCDirector:sharedDirector()
        local glview = director:getOpenGLView()
        size = glview:getFrameSize()
    end
    self.mask_:setScaleX(size.width)
    self.mask_:setScaleY(size.height)
    self.mask_:setTouchEnable(true)
    self.mask_:setOnClickListener(handler(self, self.hide))
end

--[[--
	用户展示弹窗
    @param posX: type number, 弹窗X坐标
    @param posY: type number, 弹窗Y坐标
    @return none
]]
function PopupBase:show(posX, posY)
    self.gameObject_:setPosition(posX, posY)
    self.scene_:addView(self.gameObject_)
end

--[[--
	关闭弹窗
]]
function PopupBase:hide()
    if self.managerCallback_ then
        self.managerCallback_(self)
    end

    if not self.gameObject_:isDestoryed() and self.mask_ then
        self.mask_:removeSelf(true)
        self.mask_ = nil
        local parentView = self.gameObject_:getParentView()
        if parentView then
            self.gameObject_:removeSelf(true)
        end
    end

    if self.customCloseCallback_ then
        self.customCloseCallback_(self)
    end
end

function PopupBase:setManagerCallback(callback)
    self.managerCallback_ = callback
end

function PopupBase:setCustomCloseCallback(callback)
    self.customCloseCallback_ = callback
end

--[[
    设置蒙黑层的透明度
]]
function PopupBase:setMaskOpacity(opacity)
    if self.mask_ and "number" == type(opacity) then
        self.mask_:setBackground({color4 = ccc4(0,0,0,opacity)})
    end
end

--[[
    获取蒙黑层
]]
function PopupBase:getMaskView()
    return self.mask_
end

function PopupBase:setMaskTouchable(flag)
    self.mask_:setTouchEnable(flag)
end

--[[
    定义基类，用于传递消息
]]
function PopupBase:handleMsg(msg)
end

function PopupBase:registerBtnCloseListener()
    local btnClose = self.gameObject_.btn_close_
    if btnClose then
        btnClose:setOnClickListener(function ()
            self:hide()
        end)
    end
end

function PopupBase:enableWinBodyClick()
    self.gameObject_:setTouchEnable(true)
    self.gameObject_:setOnClickListener(function () end)
end

function PopupBase:setViewController(viewController)
    self.viewController_ = viewController
end

function PopupBase:enableTouch(view, callback)
    if view then
        view:setTouchEnable(true)
        view:setOnClickListener(callback)
    end
end

---home重建resume时，是否重建本弹窗，大部分弹窗重建，玩家信息不重建，有可能玩家已经离开了
function PopupBase:getResumeFlag()
    return true
end

function PopupBase:showPopup(viewName, comName, x, y, params)
    return PopupManager:showPopup(viewName, comName, x, y, params)
end

function PopupBase:showToast(txt)
    return PopupManager:showToast(txt)
end

function PopupBase:showWithAnim(delay, callback)
    local go = self.gameObject_
    go:setOpacity(0)
    local frameCBCom = go:addComponent(ComponentDef.FRAME_CALLBACK_COM)
    frameCBCom:addFrameCallback(1, function ()
        go:runAction(JJAction:sequence(
                JJAction:delayTime(delay or 0),
                JJAction:spawnWithTwoActions(
                        JJAction:fadeIn(0.25),
                        JJAction:sequence(
                                JJAction:scaleTo(0.1, 1.1 * self.dimens_.scale_),
                                JJAction:scaleTo(0.1, self.dimens_.scale_)
                        )
                ),
                JJAction:callFunc(function ()
                    if callback then
                        callback()
                    end
                end)
        ))
    end)
end

return PopupBase