-- 玩家名片组件
local PopupRuleViewCom = class("PopupRuleViewCom", import(".PopupBase"))

function PopupRuleViewCom:awake()
    PopupRuleViewCom.super.awake(self)

    local go = self.gameObject_
    self:enableWinBodyClick()
    go.grp_root_:setOpacity(0)
    go.grp_root_:runAction(JJAction:sequenceWithTwoActions(
            JJAction:delayTime(0.2),
            JJAction:fadeIn(0.5)
    ))

    go.eff_bg_:registerSpineEventHandler(function()
        go.eff_bg_:setAnimation(0, "chixu", true)
    end, sp.EventType.ANIMATION_COMPLETE)
end

return PopupRuleViewCom