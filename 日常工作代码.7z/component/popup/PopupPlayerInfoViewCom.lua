-- 玩家名片组件
local PopupPlayerInfoViewCom = class("PopupPlayerInfoViewCom", import(".PopupBase"))
local ResourceManager = require("bomblord.util.ResourceManager")
local PrefabDef = require("bomblord.def.PrefabDef")
local LordSetting = require("bomblord.util.LordSetting")
local EventIdDefine = require("bomblord.def.EventIdDefine")
local Settings = jj.game.Settings

function PopupPlayerInfoViewCom:awake()
    PopupPlayerInfoViewCom.super.awake(self)
    self.playerInfo_ = nil
    self:enableWinBodyClick()
    self:initPlayerInfoView()
end

function PopupPlayerInfoViewCom:initPlayerInfoView()
    if self:isDestroyed() then return end
    local go = self.gameObject_
    go.musiccheck_:setOnClickListener(handler(self, self.onCheckMusic)) -- 音效开关
    go.malecheck_:setOnClickListener(handler(self, self.onCheckMale)) -- 男声开关
    go.automention_:setOnClickListener(handler(self, self.onCheckMention)) -- 自动提牌开关
    --go.autoaddhp_:setOnClickListener(handler(self, self.onCheckAddHp)) -- 自动补血开关

    local gd = self.viewController_:getGameData()
    local flag = Settings:getSoundEffect()
    go.musiccheck_:setChecked(flag)
    flag = LordSetting:getAutoPrompt()
    go.automention_:setChecked(flag)
    flag = LordSetting:getSoundMale()
    go.malecheck_:setChecked(flag)
	--flag = gd:getAutoAddHp()
	--go.autoaddhp_:setChecked(flag)
end

function PopupPlayerInfoViewCom:setPlayerInfo(info)
    self.playerInfo_ = info
    self:setNicknameText(self.playerInfo_:getNickName())
end

function PopupPlayerInfoViewCom:setNicknameText(text)
    if self:isDestroyed() then return end
    local go = self.gameObject_
    go.nickname_:setText(tostring(text) or "")
end

---createFigureHead
---创建头像
function PopupPlayerInfoViewCom:createFigureHead()
    if self:isDestroyed() then return end
    local go = self.gameObject_
    local figure = ResourceManager:createGameObject(PrefabDef.FIGURE, go)
    go.head_:addView(figure)
    local com = figure:getComponent("FigureWidgetCom")
    local params = {
        userId = self.playerInfo_:getUserId(),
        figureId = self.playerInfo_:getFigureId(),
        size = 108 * 0.7,
        shape = 2
    }
    com:setData(params)
end

---setSettingViewVisible
---设置设置组的显隐
------@param flag boolean
function PopupPlayerInfoViewCom:setSettingViewVisible(flag)
    if self:isDestroyed() then return end
    local go = self.gameObject_
    if go.setting_ then
        go.setting_:setVisible(flag)
    end
end

function PopupPlayerInfoViewCom:setBackground(bType)
    if self:isDestroyed() then return end
    local go = self.gameObject_
    local path = "popup/playerdetail/bg_mp_tankuang" .. bType .. ".png"
    go.bg_:setImage(self.theme_:getImage(path))
    self:setNicknameViewSize(bType)
end

function PopupPlayerInfoViewCom:setNicknameViewSize(bType)
    if self:isDestroyed() then return end
    local sizeList = {
        [1] = {
            width = 299,
            height = 40
        },
        [2] = {
            width = 253,
            height = 40
        }
    }
    local go = self.gameObject_
    local size = sizeList[bType]
    go.nickname_:setWithEllipsis(true)
    go.nickname_:setViewSize(size.width, size.height)
    go.nickname_:setWidthWrapContent(false)
end

---onCheckMusic
---音效开关
function PopupPlayerInfoViewCom:onCheckMusic(target)
    if target then
        local isCheck = target:isSelected()
        Settings:setSoundEffect(isCheck)
        Settings:setSoundVoice(isCheck)
        Settings:setSoundBg(isCheck)

        self:dispatchEvent(EventIdDefine.CHECK_MUSIC_SWITCH, isCheck)
    end
end

---onCheckMale
---男声开关
function PopupPlayerInfoViewCom:onCheckMale(target)
    if target then
        local isCheck = target:isSelected()
        LordSetting:setSoundMale(isCheck)
    end
end

---onCheckMention
---自动提牌开关
function PopupPlayerInfoViewCom:onCheckMention(target)
    if target then
        local isCheck = target:isSelected()
        LordSetting:setAutoPrompt(isCheck)
    end
end

---onCheckAddHp
---自动加血开关
function PopupPlayerInfoViewCom:onCheckAddHp(target)
    local gd = self.viewController_:getGameData()
    if target and gd then
        local isCheck = target:isSelected()
        gd:setAutoAddHp(isCheck)
    end
end

function PopupPlayerInfoViewCom:getResumeFlag()
    return false
end

return PopupPlayerInfoViewCom